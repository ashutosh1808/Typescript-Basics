function combine(input1, input2, printConversion) {
    var res;
    if (typeof input1 === "number" && typeof input2 === "number" || printConversion === "as-number") {
        res = +input1 + +input2; // guaranteed to be a no
    }
    else {
        res = input1.toString() + input2.toString();
    }
    return res;
    // }if(printConversion==='as-number'){
    //     return parseFloat(res)
    // }
}
var combinedAges = combine(20, 30, 'as-number');
console.log(combinedAges);
var combinedNos = combine('20', '30', 'as-number');
console.log(combinedNos);
var combinedNames = combine("Ashu", "tosh", 'as-text');
console.log(combinedNames);
