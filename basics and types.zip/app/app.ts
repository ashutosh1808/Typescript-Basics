type Combinable=number|string; //alias


function combine(input1:Combinable,input2:Combinable, printConversion:'as-number'|'as-text')
{
    let res
    if(typeof input1==="number" && typeof input2==="number" || printConversion==="as-number")
    {
        res=+input1 + +input2 // guaranteed to be a no
    }else{
        res=input1.toString()+input2.toString()
    }
    return res;
    // }if(printConversion==='as-number'){
    //     return parseFloat(res)
    // }
}

const combinedAges=combine(20,30,'as-number')
console.log(combinedAges)

const combinedNos=combine('20','30','as-number')
console.log(combinedNos)


const combinedNames=combine("Ashu","tosh",'as-text')
console.log(combinedNames)